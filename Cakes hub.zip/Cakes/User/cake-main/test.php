<?php
include('header.php');

$conn = mysqli_connect('localhost','root','','hardik');
$sql='SELECT*FROM review INNER JOIN product on review.rev_id=product.id INNER JOIN user on review.u_id=user.id';
$result= mysqli_query($conn,$sql);
print_r($result);

if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
}
print_r($data);



?>

         
         
         
         
         
         
         
         
    <!-- Testimonial Section Begin -->
    <section class="testimonial spad">
    
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <span>Testimonial</span>
                        <h2>Our client say</h2>
                    </div>
                </div>
            </div>
            <div class="row">
               
                <div class="testimonial__slider owl-carousel">
                <?php
                foreach ($data as $item) {
                    # code...
                ?> 
                    <div class="col-lg-6">
                        <div class="testimonial__item">
                            <div class="testimonial__author">
                                <div class="testimonial__author__pic">
                                    <img src="img/testimonial/ta-1.jpg" alt="">
                                </div>
                                <div class="testimonial__author__text">
                                    <h5>Kerry D.Silva</h5>
                                    <span>New york</span>
                                </div>
                            </div>
                            <div class="rating">
                                <span class="icon_star"></span>
                                <span class="icon_star"></span>
                                <span class="icon_star"></span>
                                <span class="icon_star"></span>
                                <span class="icon_star-half_alt"></span>
                            </div>
                            <p><?php echo $item['comment']?></p>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                    
                    
                </div>
        </div>
    </section>
    <!-- Testimonial Section End -->

    <?php 
    include('footer.php');
    ?>  
