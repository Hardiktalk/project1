<!DOCTYPE html>
<html>
    <head>
        <title>How to use sweet alert using PHP - Devnote.in</title>
        <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    </head>
<body><?php

?>

    <script type="text/javascript">
    $(document).ready(function() {
        swal({
            title: "congratulation",
            text: "you're registerd succsessfully!",
            icon: "success",
            buttons: true,
            successMode: true,
        })
        .then((willSuccess) => {window.location.href= '.php';
            
        });
    });
    
</script>
<?php
?>



</body>
</html>