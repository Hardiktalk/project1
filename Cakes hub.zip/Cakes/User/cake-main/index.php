<?php 
include 'header.php';
?>
<?php
$conn = mysqli_connect('localhost','root','','hardik');
$sql= "select * from category";
// echo $sql;
$result = mysqli_query($conn,$sql);
// print_r($result);
if($result->num_rows >=1)
{
   while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
  //print_r($data);
  //  mysqli_fetch_array
} 

$sql1 = "SELECT*from product INNER JOIN category on product.cat_id=category.id";
$result1 = mysqli_query($conn,$sql1);
if($result1->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result1))
   {
        $data1[]  = $row;
   }
  // print_r($data);
}
?>




?>
 
<!-- Hero Section Begin -->
<section class="hero">
    <div class="hero__slider owl-carousel">
        <div class="hero__item set-bg" data-setbg="img/hero/hero-1.jpg">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-lg-8">
                        <div class="hero__text">
                            <h2>Welcome to <br> Cakeshub </h2>
                            <a href="showproduct.php" class="primary-btn">Our product</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero__item set-bg" data-setbg="img/hero/hero-1.jpg">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-lg-8">
                        <div class="hero__text">
                            <h2>Making your life sweeter one bite at a time!</h2>
                            <a href="showproduct.php" class="primary-btn">Our product</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->

<!-- About Section Begin -->
<section class="about spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="about__text">
                    <div class="section-title">
                        <span>About Cake shop</span>
                        <h2>Cakes and bakes from the house of Queens!</h2>
                    </div>
                    <p>The "Cake Shop" is a Jordanian Brand that started as a small family business. The owners are
                    Dr. Iyad Sultan and Dr. Sereen Sharabati, supported by a staff of 80 employees.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="about__bar">
                    <div class="about__bar__item">
                        <p>Cake design</p>
                        <div id="bar1" class="barfiller">
                            <div class="tipWrap"><span class="tip"></span></div>
                            <span class="fill" data-percentage="95"></span>
                        </div>
                    </div>
                    <div class="about__bar__item">
                        <p>Cake Class</p>
                        <div id="bar2" class="barfiller">
                            <div class="tipWrap"><span class="tip"></span></div>
                            <span class="fill" data-percentage="80"></span>
                        </div>
                    </div>
                    <div class="about__bar__item">
                        <p>Cake Recipes</p>
                        <div id="bar3" class="barfiller">
                            <div class="tipWrap"><span class="tip"></span></div>
                            <span class="fill" data-percentage="90"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Section End -->


<!-- Categories Section Begin -->
<div class="categories">
   <div class="container">
        <div class="row">
            <?php  foreach ($data as $item) {
                # code...
              ?>
                
            <div class="categories__item">
                <!-- <div class="categories__item__icon"> -->
                            <!-- <span class="flaticon-029-cupcake-3"></span> -->
                            <h5><img src= "<?php echo '../../Admin/'.$item['image']?>" height='70px' width='70px'></h5>
                            <br>
                            <h5><b><?php echo $item['name']?></b></h5>
                            <!-- <h5><?php echo $item['description']?></h5> -->
                            
            </div>
            <?php }?>
            </div>
        </div>
    </div>
    <!-- Categories Section End -->

<!-- Product Section Begin -->
    <section class="product spad">
        <div class="container">
            <div class="row">
            <div class="row"> 
            <?php  foreach ($data1 as $item) {
                # code...
              ?>
            
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="product__item">
                        <div class="product__item__pic set-bg">
                        <h5><img src= "<?php echo '../../Admin/'.$item['pro_image']?>" height='255px' width='500px'></h5>
                            <div class="product__label">
                                <span><a href="#"><?php echo $item['name']?></a></span>
                            </div>
                        </div>
                        <div class="product__item__text">
                            
                            <h6><b><a href="#"><?php echo $item['pd_name']?></a></b></h6>
                            <h6><a href="#"><?php echo $item['ingredient']?></a></h6>
                            <h6><?php echo $item['price']?>  Rs.</h6><br>
                            <div class="cart_add">
                                <a href="#">Add to cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            
            <?php }?></div>
            </div>
        </div>
    </section>
    
                    




<!-- Class Section Begin -->
<section class="class spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="class__form">
                    <div class="section-title">
                        <span>Class cakes</span>
                        <h2>Made from your <br />own hands</h2>
                    </div>
                    <form action="#">
                        <input type="text" placeholder="Name">
                        <input type="text" placeholder="Phone">
                        <select>
                            <option value="">Studying Class</option>
                            <option value="">Writting Class</option>
                            <option value="">Reading Class</option>
                        </select>
                        <input type="text" placeholder="Type your requirements">
                        <button type="submit" class="site-btn">registration</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="class__video set-bg" data-setbg="img/class-video.jpg">
            <a href="https://www.youtube.com/watch?v=8PJ3_p7VqHw&list=RD8PJ3_p7VqHw&start_radio=1"
            class="play-btn video-popup"><i class="fa fa-play"></i></a>
        </div>
    </div>
</section>
<!-- Class Section End -->

<!-- Team Section Begin -->
<section class="team spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-7 col-sm-7">
                <div class="section-title">
                    <span>Our team</span>
                    <h2>Sweet Baker </h2>
                </div>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-5">
                <div class="team__btn">
                    <a href="#" class="primary-btn">Join Us</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="team__item set-bg" data-setbg="img/team/team-1.jpg">
                    <div class="team__item__text">
                        <h6>Randy Butler</h6>
                        <span>Decorater</span>
                        <div class="team__item__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="team__item set-bg" data-setbg="img/team/team-2.jpg">
                    <div class="team__item__text">
                        <h6>Randy Butler</h6>
                        <span>Decorater</span>
                        <div class="team__item__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="team__item set-bg" data-setbg="img/team/team-3.jpg">
                    <div class="team__item__text">
                        <h6>Randy Butler</h6>
                        <span>Decorater</span>
                        <div class="team__item__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="team__item set-bg" data-setbg="img/team/team-4.jpg">
                    <div class="team__item__text">
                        <h6>Randy Butler</h6>
                        <span>Decorater</span>
                        <div class="team__item__social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Team Section End -->





<?php 
include 'footer.php';
?>






