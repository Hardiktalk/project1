<!DOCTYPE html>
<html>
    <head>
        <title>How to use sweet alert using PHP - Devnote.in</title>
        <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    </head>
<body>
    
    <?php

$id=$_GET['id'];
$conn = mysqli_connect('localhost','root','','hardik');
$sql="DELETE FROM cart where id='$id'";
print_r($sql);
$result=mysqli_query($conn,$sql);
print_r($result);
//if ($result == 1) 
{
    ?>
    <script type="text/javascript">
    $(document).ready(function() {
        swal({
            title: "Are you sure!",
            text: "Do you really want to remove category!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                swal("Yaa! category successfully deleted!", {
                    icon: "success",
                });
                window.location.href= 'cart.php';
            } else {
                swal("category not deleted!", {
                    icon: "error",
                });
            }
        });
    });
    
</script>

    <?php 

}





?>
</body>
</html>












