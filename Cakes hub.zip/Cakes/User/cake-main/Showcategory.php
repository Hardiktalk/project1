<?php 
include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = "select * from category";
// echo $sql;
$result = mysqli_query($conn,$sql);
// print_r($result);
if($result->num_rows >=1)
{
   while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
  // print_r($data);
  //  mysqli_fetch_array
}
// die;

?>

<!-- Categories Section Begin -->


<div class="categories">
   <div class="container">
        <div class="row">
            <?php  foreach ($data as $item) {
                # code...
              ?>
                
            <div class="categories__item">
                <!-- <div class="categories__item__icon"> -->
                            <!-- <span class="flaticon-029-cupcake-3"></span> -->
                            <h5><img src= "<?php echo '../../Admin/'.$item['image']?>" height='90px' width='90px'></h5>
                            <h5><b><?php echo $item['name']?></b></h5>
                            <!-- <h5><?php echo $item['description']?></h5> -->
                            
            </div>
            <?php }?>
            
        </div>

    </div>
        
    
    <!-- Categories Section End -->

<?php include 'footer.php'?>
        