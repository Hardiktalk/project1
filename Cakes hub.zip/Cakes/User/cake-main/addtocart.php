<?php
session_start();

if(isset($_SESSION["email"]))
{

$id=$_GET['id']; 
$u_id=$_SESSION['u_id'];


$conn = mysqli_connect('localhost','root','','hardik');

$sql1="SELECT*FROM cart where product_id='$id' and user_id='$u_id'";
$result=mysqli_query($conn,$sql1);
print_r($result);
// die();
if($result->num_rows>=1)
{
    ?>
    echo'<script>alert("product already added")
    window.location.href=("showproduct.php")
    </script>';
    <?php
}
else
{

$sql= "select * from product where id='$id'";
echo $sql;
$data = mysqli_query($conn,$sql);
//print_r($data);
if($data->num_rows == 1)
{
    $row = mysqli_fetch_assoc($data);
    
}
// echo "<pre>";
// print_r($row['price']);
// die();


$qnt=1;
$amount = $row['price'] * $qnt;

$sql1 = "insert into cart(product_id,user_id,quntity,amount) values('$id','$u_id','$qnt','$amount')";
echo $sql1;
mysqli_query($conn,$sql1);

header('Location:cart.php');

}
}

else 
{
    header("location:signin.php");
}

?>










