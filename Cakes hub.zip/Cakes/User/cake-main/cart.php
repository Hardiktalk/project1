<?php 
include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT*,cart.id as c_id from  cart inner join product on cart.product_id= product.id 
        inner join user on cart.user_id = user.id";
$result = mysqli_query($conn,$sql);
//print_r($result);

if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
}
// $subtotal=($amount+$data);


?>




<!-- Breadcrumb Begin -->
<div class="breadcrumb-option">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__text">
                    <h2>Shopping cart</h2>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__links">
                    <a href="./index.html">Home</a>
                    <span>Shopping cart</span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->

<!-- Shopping Cart Section Begin -->
<section class="shopping-cart spad">
    <div class="container">
        <div class="row">
               
            <div class="col-lg-8">
                <div class="shopping__cart__table">
                
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th></th>
                            </tr>
                        </thead>
                        <?php foreach ($data as $item) {
                # code...
               ?>
                        <tbody>
                            <tr>
                                <td class="product__cart__item">
                                    <div class="product__cart__item__pic">
                                        <img src= "<?php echo '../../Admin/'.$item['pro_image']?>"
                                         height='70px' width='70px'>
                                    </div>
                                    <div class="product__cart__item__text">
                                    <h6><?php echo $item['pd_name']?></h6>
                                    <h5><?php echo $item['price']?>  rs.</h5>
                                    </div>
                                </td>
                                <td class="quantity__item">
                                    <div class="quantity">
                                        <div class="pro-qty">
                                            <input type="text" value=<?php echo $item['quntity']?>>
                                        </div>
                                    </div>
                                </td>
                                <td class="cart__price"><?php echo $item['amount']?>  rs.</td>

                                <td class="cart__close">
                                <a href='removecart.php?id=<?php echo $item["c_id"]?>'>
                                
                                <span class="icon_close"></span></a></td>

                                
                                



                                

                            </tr>
                            
                        </tbody>
                        
                        <?php }?>
                    </table>
                   
                </div>
                <div class="row">
                    
                </div>
            </div>
            <div class="col-lg-4">
                <div class="cart__discount">
                    <h6>Discount codes</h6>
                    <form action="#">
                        <input type="text" placeholder="Coupon code">
                        <button type="submit">Apply</button>
                    </form>
                </div>
                
                <div class="cart__total">
                    <h6>Cart total</h6>
                    <ul>
                        <li>Subtotal <span>$ 169.50</span></li>
                        <li>Total <span>$ 169.50</span></li>
                    </ul>
                    <a href="#" class="primary-btn">Proceed to checkout</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shopping Cart Section End -->



<?php include 'footer.php'?>