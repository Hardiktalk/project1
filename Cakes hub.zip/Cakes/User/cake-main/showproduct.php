<?php 
include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT *,product.id as p_id from product INNER JOIN category on product.cat_id = category.id ";
$result = mysqli_query($conn,$sql);
if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
}
?>


<!-- Breadcrumb Begin -->
<div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="breadcrumb__text">
                        <h2>Product</h2>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="breadcrumb__links">
                        <a href="index.php">Home</a>
                        <span>Product</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

<!-- Shop Section Begin -->
    <section class="shop spad">
        <div class="container">
            <div class="shop__option">
                <div class="row">
                    <div class="col-lg-7 col-md-7">
                        <div class="shop__option__search">
                            <form action="#">
                                <select><?php  foreach ($data as $item) {
                # code...
              ?>
            
                                    <option value=""><?php echo $item['name']?></option>
                                    
                                    <?php  
                                }
                                ?>
                                </select>
                                <input type="text" placeholder="Search">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-5">
                        <div class="shop__option__right">
                            <select>
                                <option value="">Default sorting</option>
                                <option value="">A to Z</option>
                                <option value="">1 - 8</option>
                                <option value="">Name</option>
                            </select>
                            <a href="#"><i class="fa fa-list"></i></a>
                            <a href="#"><i class="fa fa-reorder"></i></a>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="row"> 
            <?php  foreach ($data as $item) {
                # code...
              ?>
            
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="product__item">
                        <div class="product__item__pic set-bg">
                        <h5><img src= "<?php echo '../../Admin/'.$item['pro_image']?>" height='240px' width='240px'></h5>
                            <div class="product__label">
                                <span><?php echo $item['name']?></span>
                            </div>
                        </div>
                        <div>
                            <br>
                            <div><b><?php echo $item['pd_name']?></b></div><br>
                            <div><?php echo $item['ingredient']?></div> <br>
                            <h6><?php echo $item['price']?> rs.</h6><br>
                        <div class="text-center">
                           <a href="details.php?id=<?php echo $item['p_id']?>">
                           <button type="submit" class="btn btn-primary" name='submit'>
                            Details</button></a>
                           <a href="addtocart.php?id=<?php echo $item['p_id']?>"><button type="reset" name='submit' class="btn btn-secondary">
                            add to cart</button></a>
                        </div>
                        </div>
                    </div>
                </div>
            
            <?php }?></div>
            <div class="shop__last__option">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="shop__pagination">
                            <a href="#">1</a>
                            <a href="#">2</a>
                            <a href="#">3</a>
                            <a href="#"><span class="arrow_carrot-right"></span></a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="shop__last__text">
                            <p>Showing 1-9 of 10 results</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shop Section End -->




    <?php include 'footer.php'?>