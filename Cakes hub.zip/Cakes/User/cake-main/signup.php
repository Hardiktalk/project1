<?php 
 include 'header.php';
?>
<?php 
 if(isset($_POST['submit']))
 {
  $conn = mysqli_connect('localhost','root','','hardik');

  //  echo "<pre>";
  //   print_r($_POST);

    $user_name = $_POST['user_name'];
    $email     = $_POST['email'];
    $password  = $_POST['password'];
    $adress    = $_POST['adress'];
    $mobile    = $_POST['mobile'];
   
    
    $sql = "Insert into user (user_name,email,password,adress,mobile) 
    value ('$user_name','$email','$password','$adress','$mobile')";

    $result = mysqli_query($conn,$sql);

    // echo $result;
    }
    ?>


<section class="checkout spad">
    <div class="container">
        <div class="form">
            <form action="#" method= "post">
                <div class="row">
                    <div class="col-lg-12 col-md-3">
                      <div class= "text-center"> <h3><b>Register yourself</b></h3></div><br>
                      
                    <form class="row g-12">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="checkout__input">
                                    <p>User Name</p>
                                    <input type="text" name="name" required>
                                </div>
                            </div>
                        </div>  

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="checkout__input">
                                    <p>Email</p>
                                    <input type="text" name="email" required>
                                </div>
                            </div>
                        </div>  

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="checkout__input">
                                    <p>Password</p>
                                    <input type="password" name="password" required>
                                </div>
                            </div>
                        </div>  

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="checkout__input">
                                    <p>Adress</p>
                                    <input type="text" name="adress" required>
                                </div>
                            </div>
                        </div>  

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="checkout__input">
                                    <p>Mobile</p>
                                    <input type="tel" name="mobile" required>
                                </div>
                            </div>
                        </div> <br>

                        <div class="text-center">
                           <a href="index.php"><button type="submit" class="btn btn-primary" name='submit'>Submit</button></a>
                          <button type="reset" class="btn btn-secondary">Reset</button>
                        </div>
                        
                        </form>
                        
                        
            

    
                    </div>
                </div>
             </form>
        </div>
     </div>
</section>
</div>

<?php 
include 'footer.php';
?>