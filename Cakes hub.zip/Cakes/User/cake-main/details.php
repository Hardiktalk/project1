<?php 
include 'header.php';

$id=$_GET['id'];
$conn = mysqli_connect('localhost','root','','hardik');

$sql = "SELECT*from product where id='$id'";
$result = mysqli_query($conn,$sql);
//print_r($result);
if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
}
?>

<!-- Shop Details Section Begin -->
<section class="product-details spad">
    <div class="container">
        <div class="row">
            <?php foreach ($data as $item) {
                # code...
            
            ?>
            <div class="col-lg-6">
                <div class="product__details__img">
                    <div class="product__details__big__img">
                        <img class="big_img" src="https://cdn.igp.com/f_auto,q_auto,t_pnopt8prodlp/products/p-chocolate-fudge-brownie-cake-half-kg--109548-m.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="product__details__text">
                    <!-- <div class="product__label"></div> -->
                    <h4><?php echo $item['pd_name']?></h4>
                    <h5><?php echo $item['price']?></h5>
                    <h5><?php echo $item['weight']?></h5>
                    
                    <p><?php echo $item['ingredient']?></p>

                    <a href="addtocart.php?id=<?php echo $item['id']?>"><button>
                    <class="primary-btn">Add to cart</a></button> 
                    <a href="#" class="heart__btn"><span class="icon_heart_alt"></span></a>
                </div>
                </div>
            </div>
            <?php }?>
        </div>
    </div>
</section>
<!-- Shop Details Section End -->


<?php include 'footer.php'
?>























