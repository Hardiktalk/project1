<?php

?>
<script>
    alert('product submited succesfully');
    window.location.href='showproduct.php';
</script>
<?php
?>