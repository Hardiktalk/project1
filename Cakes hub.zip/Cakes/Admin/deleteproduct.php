<?php
$id = $_GET['id'];
$conn = mysqli_connect('localhost','root','','hardik');

$sql = "delete from product where id = '$id'";
$result = mysqli_query($conn,$sql);
if($result == 1)
{
    ?>
    <script>
        alert('product deleted');
       // window.location.href='showproduct.php';
     </script>
    
    <?php 

   
}



?>

</body>
</html>