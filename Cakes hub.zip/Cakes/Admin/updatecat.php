<?php include 'header.php' ?>

<?php 
$conn = mysqli_connect('localhost','root','','hardik');
$id = $_GET['id'];
$sql = "SELECT * from category where id='$id'";
$result = mysqli_query($conn,$sql);
if($result->num_rows>=1)
{
    $data = mysqli_fetch_assoc($result);
}
 if(isset($_POST['submit']))
 {

  //  echo "<pre>";
  //   print_r($_POST);

    $name = $_POST['name'];
    $description = $_POST['description'];
    $target_dir = "uploads/";
    $target_file = $target_dir . time().basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

   $sql = "Insert into category (name,description,image) values(
    '$name' , '$description','$target_file')";

    $sql1 = "Update category set name = '$name',description='$description',image='$target_file' where id='$id'";

    echo $sql1;
    
    $result1 = mysqli_query($conn,$sql1);

    echo $result1;
    



 }

?>
 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Update Category</h1>
      <nav>
        <!-- <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Layouts</li>
        </ol> -->
      </nav>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Update Category</h5>

              <!-- Horizontal Form -->
              <form method='post' enctype='multipart/form-data'>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Category Name</label>
                  <div class="col-sm-10">
                  <input type="text" class="form-control" id="inputText" name='name' 
                  value=<?php echo $data['name']?>>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                    Description
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="" name='description' 
                    value=<?php echo $data['description']?>>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">
                        Image
                  </label>
                  <div class="col-sm-10">
                    <input type="file" class="form-control" id="file" name='image' 
                    value=<?php echo $data['image']?> >
                  </div>
                </div>
              
            
                <div class="text-center">
                  <button type="submit" class="btn btn-primary" name='submit'>Submit</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>

        

        </div>

     
      </div>
    </section>

  </main><!-- End #main -->
<?php include 'footer.php' ?>