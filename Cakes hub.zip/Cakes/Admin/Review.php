<?php 
 include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = ("SELECT *,review.id as r_id FROM review INNER JOIN product ON review.rev_id = product.id 
        INNER JOIN user ON review.u_id = user.id");

$result = mysqli_query($conn,$sql);
if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
}
// print_r($data);

?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Review</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Components</li>
          <li class="breadcrumb-item active">Review</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
         
          <!-- Table with stripped rows -->
          <table class="table datatable">
            <thead>
              <tr>
                
                <th scope="col">Name</th>
                <th scope="col">comment</th>
                
                <th scope="col">product</th>
                
                <th scope="col">Action</th>
               
              </tr>
            </thead>
            <tbody>
            <?php  foreach ($data as $item) {
                # code...
              ?>
              <tr>
                <th scope="row"><?php echo $item['user_name']?></th>
                <td><?php echo $item['comment']?></td>
                
                <td><?php echo $item['pd_name']?></td>
                
                
                
                
                <td>
                <a href='reviewdelete.php?id=<?php echo $item["r_id"]?>'>
                <button i class="bi bi-trash btn-danger"></i></button></a>

                <!-- <a href='updatereview.php?id=<?php echo $item["r_id"]?>'>
                <button i class="bi bi-pencil-square btn-primary"></i> </button></a> -->

                </td>
              </tr>
              <?php }?>
            
            </tbody>
          </table>
          <!-- End Table with stripped rows -->

        </div>
      </div>

    </div>
  </div>
</section>

  </main><!-- End #main -->

  <?php include 'footer.php';?>