<?php 
//include 'header.php';

$id = $_GET['id'];
$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT*from user where id='$id'";
$result = mysqli_query($conn,$sql);
if($result->num_rows >=1)
{
  $data = mysqli_fetch_assoc($result);
}
if(isset($_POST['submit']))
 {
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $adress = $_POST['adress'];
    $mobile = $_POST['mobile'];
    
    
    $sql = "Insert into user (user_name,email,password,adress,mobile,role) value (
    '$user_name','$email','$password','$adress','$mobile','')";

    $sql1 = "UPDATE user SET user_name ='$user_name',email='$email',password='$password',adress='$adress',
    mobile='$mobile' where id='$id'";

    $result = mysqli_query($conn,$sql1);
    }

?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>Update user</h1>
  <nav>
    <!-- <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item">Forms</li>
      <li class="breadcrumb-item active">Layouts</li>
    </ol> -->
  </nav>
</div><!-- End Page Title -->
<section class="section">
  <div class="row">
    <div class="col-lg-12 ">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Update user</h5>

          <!-- Horizontal Form -->
          <form method='post' enctype='multipart/form-data'>
             
            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">user Name</label>
              <div class="col-sm-10">
               <input type="text" class="form-control" id="inputText" name='user_name'
               value='<?php echo $data['user_name']?>'>
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
              Email
              </label>
              <div class="col-sm-10">
                <input type="email" class="form-control" id="" name='email'
                value='<?php echo $data['email']?>'>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputPassword3" class="col-sm-2 col-form-label">
              Password
              </label>
              <div class="col-sm-10">
                <input type="password" class="form-control" id="file" name='password'
                value='<?php echo $data['password']?>'>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
              Adress
              </label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="" name='adress'
                value='<?php echo $data['adress']?>'>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
              mobile no.
              </label>
              <div class="col-sm-10">
                <input type="tel" class="form-control" id="" name='mobile'
                value='<?php echo $data['mobile']?>'>
              </div>
            </div>

            <!-- <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
              role
              </label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="" name='role'>
              </div>
            </div> -->


          
        
            <div class="text-center">
              <button type="submit" class="btn btn-primary" name='submit'>Submit</button>
              <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
          </form><!-- End Horizontal Form -->

        </div>
      </div>

    

    </div>

 
  </div>
</section>

</main><!-- End #main -->

  <?php include 'footer.php';?>