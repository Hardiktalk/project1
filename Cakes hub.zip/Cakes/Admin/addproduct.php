<?php 

include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT*FROM category";
// echo $sql;
$result = mysqli_query($conn,$sql);
// print_r($result);
if($result->num_rows >=1)
{
   while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
  // print_r($data);
  //  mysqli_fetch_array
}
//  die;





?>


<?php 
 if(isset($_POST['submit']))
 {
  


  //  echo "<pre>";
  //   print_r($_POST);

    $pd_name = $_POST['pd_name'];
    
    $target_dir = "uploads/";
    $target_file = $target_dir . time().basename($_FILES["pro_image"]["name"]);
    move_uploaded_file($_FILES["pro_image"]["tmp_name"], $target_file);

    $ingredient = $_POST['ingredient'];

    $price = $_POST['price'];
    $qnt = $_POST['qnt'];
    $weight = $_POST['weight'];
    $cat_id = $_POST['cat_id'];
    
    $sql = "Insert into product (pd_name,pro_image,ingredient,price,qnt,weight,cat_id) 
    values('$pd_name','$target_file','$ingredient','$price','$qnt','$weight','$cat_id')";

    $result = mysqli_query($conn,$sql);

    echo $result;
    



 }

?>
 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Add product</h1>
      <nav>
        <!-- <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Layouts</li>
        </ol> -->
      </nav>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Add product</h5>

              <!-- Horizontal Form -->
              <form method='post' enctype='multipart/form-data'>
                
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                    product Name
                  </label>
                  <div class="col-sm-10">
                   <input type="text" class="form-control" id="inputText" name='pd_name'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                    image
                  </label>
                  <div class="col-sm-10">
                   <input type="file" class="form-control" id="file" name='pro_image'>
                  </div>
                </div>


                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                    ingredient
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="" name='ingredient'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">
                        price
                  </label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" id="file" name='price'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                    Quntity
                  </label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" id="" name='qnt'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                    Weight
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="" name='weight'>
                  </div>
                </div>

                <div class="row mb-3">
                <label for="number" class="col-sm-2 col-form-label">
                    Category
                  </label>
                  <div class="col-sm-10">
                    
                  <div class="text-center">
                    
                <select class="form-control" name= 'cat_id'>
                  <?php foreach ($data as $item) 
                  {
                # code...
                  ?>
                 <option value="<?php echo $item['id'] ?>"><?php echo $item['name']?></option>
                  <?php }?>                  
                  </select>                   
                  </div>
                <br>                                
                  
                

              <div class="text-center">
              <button type="submit" class="btn btn-primary" name='submit'>Submit</button>
              <button type="reset" class="btn btn-secondary">Reset</button>
              </div>
              </form>
              <!-- End Horizontal Form -->
            </div>
          </div>
        </div>
      </div>
    </section>
</main>

<!-- End #main -->





<?php include 'footer.php' ?>
              
            
               