<?php include 'header.php' ?>

<?php

$conn = mysqli_connect('localhost','root','','hardik');
$id = $_GET['id'];

$sql = "SELECT *, category.id as c_id from category";
$result = mysqli_query($conn,$sql);
if($result->num_rows>=1)
{
   
    while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row; 
   }
}

$sql3 = "SELECT * from product WHERE id='$id'";
$result3 = mysqli_query($conn,$sql3);
//print_r($result3);
if($result3->num_rows >=1)
{
  $data3 = mysqli_fetch_assoc($result3);
}

print_r($data3);


if(isset($_POST['submit']))
{
    $target_dir = "uploads/";
    $target_file = $target_dir . time().basename($_FILES["pro_image"]["name"]);
    move_uploaded_file($_FILES["pro_image"]["tmp_name"], $target_file); 

    $pd_name = $_POST['pd_name'];

    $ingredient = $_POST['ingredient'];
    $price = $_POST['price'];
    $qnt = $_POST['qnt'];
    $weight = $_POST['weight'];
    $cat_id = $_POST['cat_id'];


    $sql1 = "INSERT INTO product (pro_image,pd_name,ingredient,price,qnt,weight,cat_id) 
             values('$target_file','$pd_name','$ingredient','$price','$qnt','$weight','$cat_id')";

    $sql2 = " UPDATE product set pro_image='$target_file',pd_name='$pd_name', ingredient='$ingredient', 
              price='$price', qnt='$qnt', weight='$weight', cat_id='$cat_id' where id='$id'";

    $result1 = mysqli_query($conn,$sql2);
    
}
?>

<main id="main" class="main">

<div class="pagetitle">
  <h1>Update product</h1>
  <nav>
    <!-- <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item">Forms</li>
      <li class="breadcrumb-item active">Layouts</li>
    </ol> -->
  </nav>
</div><!-- End Page Title -->
<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Uodate product</h5>

          <!-- Horizontal Form -->
          <form method='post' enctype='multipart/form-data'>

             <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">image</label>
              <div class="col-sm-10">
               <input type="file" class="form-control" id="file" name='pro_image'
               value='<?php echo $data3['pro_image']?>'>
              </div>
            </div>
            
            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">product Name</label>
              <div class="col-sm-10">
               <input type="text" class="form-control" id="inputText" name='pd_name'
               value='<?php echo $data3['pd_name']?>'>
              </div>
            </div>


            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
                ingredient
              </label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="" name='ingredient'
                value='<?php echo $data3['ingredient']?>'>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputPassword3" class="col-sm-2 col-form-label">
                    price
              </label>
              <div class="col-sm-10">
                <input type="number" class="form-control" id="file" name='price'
                value='<?php echo $data3['price']?>'>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
                Quntity
              </label>
              <div class="col-sm-10">
                <input type="number" class="form-control" id="" name='qnt'
                value='<?php echo $data3['qnt']?>'>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputEmail3" class="col-sm-2 col-form-label">
                Weight
              </label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="" name='weight'
                value='<?php echo $data3['weight']?>'>
              </div>
            </div>

            <div class="row mb-3">
            <label for="number" class="col-sm-2 col-form-label">
                Category
              </label>
              <div class="col-sm-10">
                
              <div class="text-center">
                
            <select class="form-control" name= 'cat_id'>
              <?php foreach ($data as $item) 
              {
            # code...
              ?>
             <option value="<?php echo $item['c_id'] ?>"><?php echo $item['name']?></option>
              <?php }?>                  
              </select>                   
              </div>
            <br>                                
              
            

             <div class="text-center">
              <button type="submit" class="btn btn-primary" name='submit'>Submit</button>
              <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
          </form><!-- End Horizontal Form -->

        </div>
      </div>

    

    </div>

 
  </div>
</section>

</main><!-- End #main -->
<?php include 'footer.php' ?>
          
        
           