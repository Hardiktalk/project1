<?php include 'header.php' 
?>

<?php
$id = $_GET['id'];
$conn = mysqli_connect('localhost','root','','hardik');

$sql3 = "SELECT *FROM review";
$result3 = mysqli_query($conn,$sql3);
if($result3->num_rows>=1)
{
  $data3= mysqli_fetch_assoc($result3);
}

$sql = "SELECT *FROM user";
$result = mysqli_query($conn,$sql);
if($result->num_rows>=1)
{
  while($row = mysqli_fetch_assoc($result))
  {
       $data[]  = $row;
  }
 // print_r($data);
 //  mysqli_fetch_array 
}
//  die;

$sql1 = "SELECT *,product.id as p_id FROM product";
$result1 = mysqli_query($conn,$sql1);
if($result1->num_rows>=1);
{
  while($row1 = mysqli_fetch_assoc($result1))
  {
       $data1[]  = $row1;
  }
}

 if(isset($_POST['submit']))
 {
    $u_id = $_POST['u_id'];
    $rev_id = $_POST['rev_id'];
    $comment = $_POST['comment'];
   
    $sql1 = "Insert into review (u_id,rev_id,comment) values(
    '$u_id','$rev_id','$comment')";

    $sql2 = "UPDATE review u_id='$u_id',rev_id=' $rev_id',comment='$comment' where id='$id'";
    $result1 = mysqli_query($conn,$sql2);

  }

?>


  <main id="main" class="main">

<div class="pagetitle">
  <h1>ADD PRODUCT</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>
      <li class="breadcrumb-item">Review</li>
      <li class="breadcrumb-item active">Layouts</li>
    </ol>
  </nav>

<div class="col-lg-12">

<div class="card">
  <div class="card-body">
    <h5 class="card-title">add review</h5>

    <!-- Vertical Form -->
            <form class="row g-3" method="post" enctype='multipart/form-data'>
      
                <div class="col-md-12">
                <label for="inputAddress" class="form-label">User name</label>
                  <select id="inputState" class="form-select" name="u_id">
                    <?php foreach ($data as $item) 
                    {
                        # code...
                    ?>
                    <option value="<?php echo $item['id']?>"><?php echo $item['user_name']?></option>
                    <?php
                    }
                    ?>
                    
                  </select>
                </div>

                <div class="col-md-12">
                <label for="inputAddress" class="form-label">Product name</label>
                  <select id="inputState" class="form-select" name="rev_id">
                    <?php foreach ($data1 as $item) 
                    {
                        # code...
                    ?>
                    <option value="<?php echo $item['p_id']?>"><?php echo $item['pd_name']?></option>
                    <?php
                    }
                    ?>
                    
                  </select>
                </div>


                <div class="col-12">
                <label for="inputAddress" class="form-label">Comment</label>
                <input type="text" class="form-control" id="inputAddress" name="comment"
                value="<?php echo $data3['comment']?>">
                 </div>

                <!-- <div class="text-center">
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
                </div> -->
                </form><!-- Vertical Form -->

  </div>
</div>
</main><!-- End #main -->


<?php include 'footer.php' ?>