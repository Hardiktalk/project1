<?php 
include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT *,product.id as p_id from product INNER JOIN category on product.cat_id = category.id ";
$result = mysqli_query($conn,$sql);
if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row; 
   }
}

?>
<main id="main" class="main">

<div class="pagetitle">
  <h1>Show Product</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item">Product</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
         
          <!-- Table with stripped rows -->
          <table class="table datatable">
            <thead>
              <tr>
                
                <th>Name</th>
                <th>Product</th>
                <th>Ingredient</th>
                <th>Price</th>
                <th>Quntity</th>
                <th>Weight</th>
                <th>Category</th>
                <th>Action</th>
               
              </tr>
            </thead>
            <tbody>
            <?php  foreach ($data as $item) {
                # code...
              ?>
              <tr>
                <th><?php echo $item['pd_name']?></th>
                <td><img src= "<?php echo $item['pro_image']?>" height='50px' width='50px'></td>
                <td><?php echo $item['ingredient']?></td>
                <td><?php echo $item['price']?>  rs.</td>
                <td><?php echo $item['qnt']?></td>
                <td><?php echo $item['weight']?></td>
                <td><?php echo $item['name']?></td>
                <td>
                <a href='deleteproduct.php?id=<?php echo $item["p_id"]?>'>
                <button i class="bi bi-trash btn-danger"></i></button></a>
                    
                <a href='updatepro.php?id=<?php echo $item["p_id"]?>'>
                    <button i class="bi bi-pencil-square btn-primary"></i> </button></a>


                </td>
              </tr>
              <?php }?>
            
            </tbody>
          </table>
          <!-- End Table with stripped rows -->

        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->

<?php include 'footer.php';?>
