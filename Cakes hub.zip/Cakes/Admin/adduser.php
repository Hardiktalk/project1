<?php include 'header.php' ?>

<?php 
 if(isset($_POST['submit']))
 {
  $conn = mysqli_connect('localhost','root','','hardik');

  //  echo "<pre>";
  //   print_r($_POST);

    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    //   $target_dir = "../Common/uploads/";
    // $target_file = $target_dir . time().basename($_FILES["image"]["name"]);
    // move_uploaded_file($_FILES["image"]["tmp_name"], $target_file); 
    $password = $_POST['password'];
    $adress = $_POST['adress'];
    $mobile = $_POST['mobile'];
    // $role = $_POST['role'];
    
    $sql = "Insert into user (user_name,email,password,adress,mobile,role) value (
    '$user_name','$email','$password','$adress','$mobile','')";

    $result = mysqli_query($conn,$sql);

    echo $result;
    }
    ?>
 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Add user</h1>
      <nav>
        <!-- <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Layouts</li>
        </ol> -->
      </nav>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">
        <div class="col-lg-12 ">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Add user</h5>

              <!-- Horizontal Form -->
              <form method='post' enctype='multipart/form-data'>
                 
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">user Name</label>
                  <div class="col-sm-10">
                   <input type="text" class="form-control" id="inputText" name='user_name'>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                  Email
                  </label>
                  <div class="col-sm-10">
                    <input type="email" class="form-control" id="" name='email'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">
                  Password
                  </label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" id="file" name='password'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                  Adress
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="" name='adress'>
                  </div>
                </div>

                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                  mobile no.
                  </label>
                  <div class="col-sm-10">
                    <input type="tel" class="form-control" id="" name='mobile'>
                  </div>
                </div>

                <!-- <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">
                  role
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="" name='role'>
                  </div>
                </div> -->


              
            
                <div class="text-center">
                  <button type="submit" class="btn btn-primary" name='submit'>Submit</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>

        

        </div>

     
      </div>
    </section>

  </main><!-- End #main -->
<?php include 'footer.php' ?>