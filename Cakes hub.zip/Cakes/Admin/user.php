<?php 
include 'header.php';

$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT*from user";
$result = mysqli_query($conn,$sql);
if($result->num_rows >=1)
{
  while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
}

?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Review</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Components</li>
          <li class="breadcrumb-item active">user</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
         
          <!-- Table with stripped rows -->
          <table class="table datatable">
            <thead>
              <tr>
                
                <th scope="col">User Name</th>
                <th scope="col">email</th>
                <th scope="col">password</th>
                <th scope="col">Adress</th>
                <th scope="col">Mobile no.</th>
                <th scope="col">role</th>
                
                <th scope="col">Action</th>
               
              </tr>
            </thead>
            <tbody>
            <?php  foreach ($data as $item) {
                # code...
              ?>
              <tr>
                <th scope="row"><?php echo $item['user_name']?></th>
                <td><?php echo $item['email']?></td>
                <td><?php echo $item['password']?></td>
                <td><?php echo $item['adress']?></td>
                <td><?php echo $item['mobile']?></td>
                <td><?php echo $item['role']?></td>
                
                
                <td>
                <a href='deleteuser.php?id=<?php echo $item["id"]?>'>
                <button i class="bi bi-trash btn-danger"></i></button></a>
                    
                <a href='updateuser.php?id=<?php echo $item["id"]?>'>
                <button i class="bi bi-pencil-square btn-primary"></i> </button></a>


                </td>
              </tr>
              <?php }?>
            
            </tbody>
          </table>
          <!-- End Table with stripped rows -->

        </div>
      </div>

    </div>
  </div>
</section>

  </main><!-- End #main -->

  <?php include 'footer.php';?>