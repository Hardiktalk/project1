<?php include 'header.php' 
?>

<?php
$conn = mysqli_connect('localhost','root','','hardik');
$sql = "SELECT *FROM user";
$result = mysqli_query($conn,$sql);
{
  while($row = mysqli_fetch_assoc($result))
  {
       $data[]  = $row;
  }
 // print_r($data);
 //  mysqli_fetch_array 
}
//  die;

$sql1 = "SELECT *,product.id as p_id FROM product";
$result1 = mysqli_query($conn,$sql1);
{
  while($row1 = mysqli_fetch_assoc($result1))
  {
       $data1[]  = $row1;
  }
 // print_r($data);
 //  mysqli_fetch_array 
}
//  die;





?>

<?php 
 if(isset($_POST['submit']))
 {
 

  //  echo "<pre>";
  //   print_r($_POST);

    $u_id = $_POST['u_id'];
    $rev_id = $_POST['rev_id'];
    $comment = $_POST['comment'];
    //   $target_dir = "../Common/uploads/";
    // $target_file = $target_dir . time().basename($_FILES["image"]["name"]);
    // move_uploaded_file($_FILES["image"]["tmp_name"], $target_file); 
    
   
    $sql1 = "Insert into review (u_id,rev_id,comment) values(
    '$u_id','$rev_id','$comment')";

    $result1 = mysqli_query($conn,$sql1);

  }

?>


  <main id="main" class="main">

<div class="pagetitle">
  <h1>ADD PRODUCT</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>
      <li class="breadcrumb-item">Review</li>
      <li class="breadcrumb-item active">Layouts</li>
    </ol>
  </nav>

<div class="col-lg-12">

<div class="card">
  <div class="card-body">
    <h5 class="card-title">add review</h5>

    <!-- Vertical Form -->
            <form class="row g-3" method="post" enctype='multipart/form-data'>
      
                <div class="col-md-12">
                <label for="inputAddress" class="form-label">User name</label>
                  <select id="inputState" class="form-select" name="u_id">
                    <?php foreach ($data as $item) 
                    {
                        # code...
                    ?>
                    <option value="<?php echo $item['id']?>"><?php echo $item['user_name']?></option>
                    <?php
                    }
                    ?>
                    
                  </select>
                </div>

                <div class="col-md-12">
                <label for="inputAddress" class="form-label">Product name</label>
                  <select id="inputState" class="form-select" name="rev_id">
                    <?php foreach ($data1 as $item) 
                    {
                        # code...
                    ?>
                    <option value="<?php echo $item['p_id']?>"><?php echo $item['pd_name']?></option>
                    <?php
                    }
                    ?>
                    
                  </select>
                </div>


                <div class="col-12">
                <label for="inputAddress" class="form-label">Comment</label>
                <input type="text" class="form-control" id="inputAddress" name="comment">
                 </div>

                <div class="text-center">
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
                </form><!-- Vertical Form -->

  </div>
</div>
</main><!-- End #main -->


<?php include 'footer.php' ?>