<?php 
include 'header.php';?>

<?php
$conn = mysqli_connect('localhost','root','','hardik');
$sql = "select * from category";
// echo $sql;
$result = mysqli_query($conn,$sql);
// print_r($result);
if($result->num_rows >=1)
{
   while($row = mysqli_fetch_assoc($result))
   {
        $data[]  = $row;
   }
  // print_r($data);
  //  mysqli_fetch_array
}
// die;


?>
  <main id="main" class="main">

<!-- <div class="pagetitle">
  <h1>Show Category</h1>
  <a type='button'  href = 'addcategory.php' class='btn btn-info'>Add Category </a> -->
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item">Category</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
         
          <!-- Table with stripped rows -->
          <table class="table datatable">
            <thead>
              <tr>
              
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Image</th>
                <th scope="col">Action</th>
               
              </tr>
            </thead>
            <tbody>
              <?php  foreach ($data as $item) {
                # code...
              ?>
              <tr>
                <th scope="row"><?php echo $item['name']?></th>

                <td><?php echo $item['description'] ?></td>

                <td ><img src= "<?php echo $item['image']?>" height='50px' width='50px'></td>

                <td>
                   <a href='deletecategory.php?id=<?php echo $item["id"]?>'>
                    <button i class="bi bi-trash btn-danger"></i></button></a>
                    
                    <a href='updatecat.php?id=<?php echo $item["id"]?>'>
                    <button i class="bi bi-pencil-square btn-primary"></i> </button></a>

                </td>
              </tr>
              <?php } ?>
                

                </tbody>
          </table>
          <!-- End Table with stripped rows -->

        </div>
      </div>

    </div>
  </div>
</section>

</main><!-- End #main -->

<?php include 'footer.php';?>
                
                
                
                

             

      
            
            