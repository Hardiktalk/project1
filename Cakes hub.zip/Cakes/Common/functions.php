<?php 
session_start();
 function Connection()
 {
    $conn = mysqli_connect('localhost','root','','hardik');
    // hostname,username,password,dbtaname
    // print_r($conn);
    return $conn;
 }

function Login($tbl,$data,$role)
 {
    // echo"Hello Login";

    $conn = Connection();
    $email = $data['email'];
    $password = $data['password'];

    $sql = "SELECT * from $tbl where email = '$email' and 
    password = '$password' and 
    role = '$role'";

    // echo $sql;
    $ans = mysqli_query($conn,$sql);
    // print_r($ans);
    if($ans->num_rows == 1)
    {      $_SESSION['email'] = $email;
           return 1;
    }
    else{
            return 0;
    }
 }



?>